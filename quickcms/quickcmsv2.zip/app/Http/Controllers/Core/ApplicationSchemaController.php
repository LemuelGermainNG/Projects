<?php

declare(strict_types=1);

namespace App\Http\Controllers\Core;

use App\Core\Application\Application;
use App\Core\Application\ApplicationManager;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

final class ApplicationSchemaController
{
    public function __construct(
        protected readonly ApplicationManager $manager,
    ) {
    }

    /**
     * Return application metadata.
     */
    public function show(
        string $application,
    ): JsonResponse {
        $this->discoverApplications();

        $metadata = Application::find(
            $application,
        );

        if ($metadata === null) {
            return response()->json(
                [
                    'message' => 'Application not found.',
                ],
                Response::HTTP_NOT_FOUND,
            );
        }

        return response()->json([
            'data' => $metadata->toArray(),
        ]);
    }

    /**
     * Return the compiled application schema.
     */
    public function schema(
        string $application,
    ): JsonResponse {
        $this->discoverApplications();

        $metadata = Application::find(
            $application,
        );

        if ($metadata === null) {
            return response()->json(
                [
                    'message' => 'Application not found.',
                ],
                Response::HTTP_NOT_FOUND,
            );
        }

        return response()->json([
            'data' => [
                'application' => $metadata->toArray(),
                'schema' => [
                    'pages' => $this->manager
                        ->registry()
                        ->pages($metadata->id()),
                    'navigation' => $this->manager
                        ->registry()
                        ->navigation($metadata->id()),
                ],
            ],
        ]);
    }

    protected function discoverApplications(): void
    {
        $this->manager->discover(
            config(
                'quickcms.applications_path',
                app_path('Applications'),
            ),
        );
    }
}
