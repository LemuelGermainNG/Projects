<?php

declare(strict_types=1);

namespace App\Runtime\Navigation;

use App\Core\Runtime\Contracts\Navigation;
use App\Core\Schema\Navigation\NavigationItemSchema;
use App\Core\Schema\Navigation\NavigationSchema;
use App\Core\Support\Enum\Icons\Heroicons;
use App\Runtime\Pages\DashboardPage;
use App\Runtime\Pages\UserCreatePage;
use App\Runtime\Pages\UsersPage;

final class NavigationProvider implements Navigation
{
    public function schema(): NavigationSchema
    {
        return NavigationSchema::make()
            ->label('Administration')
            ->icon(Heroicons::Squares2x2)
            ->items([
                NavigationItemSchema::make()
                    ->label('Dashboard')
                    ->icon(Heroicons::Home)
                    ->route(DashboardPage::class),

                NavigationItemSchema::make()
                    ->label('Users')
                    ->icon(Heroicons::Users)
                    ->children([
                        NavigationItemSchema::make()
                            ->label('List')
                            ->icon(Heroicons::User)
                            ->route(UsersPage::class),

                        NavigationItemSchema::make()
                            ->label('Create')
                            ->icon(Heroicons::UserPlus)
                            ->route(UserCreatePage::class),
                    ]),
            ]);
    }

    public function metadata(): array
    {
        return [
            'section' => 'administration',
        ];
    }
}
