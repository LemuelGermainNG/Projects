<?php

declare(strict_types=1);

namespace App\Runtime\Pages;

use App\Core\Runtime\Contracts\Page;
use App\Core\Schema\Form\FormSchema;
use App\Core\Schema\Form\Input\Email\EmailInputSchema;
use App\Core\Schema\Form\Input\Text\TextInputSchema;
use App\Core\Schema\Form\State\StateSchema;
use App\Core\Schema\Form\Validation\Validation;
use App\Core\Schema\Page\PageSchema;

final class UserCreatePage implements Page
{
    public function id(): string
    {
        return 'users.create';
    }

    public function content(): PageSchema
    {
        return PageSchema::make()
            ->content(
                FormSchema::make()
                    ->schema([
                        TextInputSchema::make()
                            ->name('name')
                            ->placeholder('John Doe')
                            ->state(
                                StateSchema::make()
                                    ->path('name')
                                    ->default(''),
                            )
                            ->validation(
                                Validation::make()
                                    ->required()
                                    ->string()
                                    ->min(2),
                            ),

                        EmailInputSchema::make()
                            ->name('email')
                            ->placeholder('john@example.com')
                            ->state(
                                StateSchema::make()
                                    ->path('email')
                                    ->default(''),
                            )
                            ->validation(
                                Validation::make()
                                    ->required()
                                    ->email(),
                            ),
                    ])
                    ->props([
                        'submitLabel' => 'Create user',
                    ]),
            );
    }

    public function metadata(): array
    {
        return [
            'section' => 'users',
            'action' => 'create',
        ];
    }
}
