<?php

declare(strict_types=1);

namespace App\Runtime\Pages;

use App\Core\Runtime\Contracts\Page;
use App\Core\Schema\Page\PageSchema;
use App\Core\Schema\Widget\Data\Pagination\WidgetPaginationSchema;
use App\Core\Schema\Widget\Data\Records\WidgetRecordsSchema;
use App\Core\Schema\Widget\Data\WidgetDataSchema;
use App\Core\Schema\Widget\Table\TableWidgetSchema;

final class UsersPage implements Page
{
    public function id(): string
    {
        return 'users';
    }

    public function content(): PageSchema
    {
        return PageSchema::make()
            ->content(
                TableWidgetSchema::make()
                    ->key('users')
                    ->title('Users')
                    ->description('Manage application users.')
                    ->tableColumns([
                        [
                            'key' => 'name',
                            'label' => 'Name',
                            'sortable' => true,
                            'searchable' => true,
                        ],
                        [
                            'key' => 'email',
                            'label' => 'Email',
                            'sortable' => true,
                            'searchable' => true,
                        ],
                        [
                            'key' => 'status',
                            'label' => 'Status',
                            'format' => 'badge',
                        ],
                    ])
                    ->rowKey('id')
                    ->data(
                        WidgetDataSchema::make()
                            ->records(
                                WidgetRecordsSchema::make()
                                    ->records([
                                        [
                                            'id' => 1,
                                            'name' => 'John Doe',
                                            'email' => 'john@example.com',
                                            'status' => 'active',
                                        ],
                                        [
                                            'id' => 2,
                                            'name' => 'Jane Doe',
                                            'email' => 'jane@example.com',
                                            'status' => 'active',
                                        ],
                                    ]),
                            )
                            ->pagination(
                                WidgetPaginationSchema::make()
                                    ->enabled()
                                    ->perPage(20)
                                    ->page(1),
                            ),
                    ),
            );
    }

    public function metadata(): array
    {
        return [
            'section' => 'users',
        ];
    }
}
