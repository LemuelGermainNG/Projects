<?php

declare(strict_types=1);

namespace App\Core\Builder;

use App\Core\Schema\Schema;
use App\Core\Support\Contracts\EvaluationContextInterface;
use App\Core\Support\Contexts\EvaluationContext;
use InvalidArgumentException;

final class BuilderRegistry
{
    /**
     * Registered builders.
     *
     * @var array<class-string<Schema>, class-string<Builder>>
     */
    protected array $builders = [];

    /**
     * Register a builder for a schema.
     *
     * @param class-string<Schema> $schema
     * @param class-string<Builder> $builder
     */
    public function register(
        string $schema,
        string $builder,
    ): static {
        $this->builders[$schema] = $builder;

        return $this;
    }

    /**
     * Compile a schema.
     */
    public function build(
        Schema $schema,
        ?EvaluationContextInterface $context = null,
    ): array {
        $builder = $this->resolve($schema);

        $context ??= new EvaluationContext();

        return new $builder(
            $schema,
            $this,
            $context,
        )->build();
    }

    /**
     * Returns all registered builders.
     *
     * @return array<class-string<Schema>, class-string<Builder>>
     */
    public function builders(): array
    {
        return $this->builders;
    }

    /**
     * Resolve the builder for a schema.
     *
     * Supports inheritance:
     * - exact match
     * - parent class
     * - implemented interface
     *
     * @return class-string<Builder>
     */
    protected function resolve(
        Schema $schema,
    ): string {
        $schemaClass = $schema::class;

        /*
         * Exact match.
         */
        if (isset($this->builders[$schemaClass])) {
            return $this->builders[$schemaClass];
        }

        /*
         * Parent classes / interfaces.
         */
        foreach ($this->builders as $registeredSchema => $builder) {
            if (is_a($schema, $registeredSchema)) {
                return $builder;
            }
        }

        throw new InvalidArgumentException(
            sprintf(
                'No builder registered for schema [%s].',
                $schemaClass,
            ),
        );
    }
}
